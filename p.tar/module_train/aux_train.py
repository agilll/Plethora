


# folders and filenames involved in corpus construction

LEE_D2V_MODEL = "model_d2v_lee"

OWN_D2V_MODEL = "model_d2v_own"

CORPUS_FOLDER = "../CORPUS/"

TRAINING_TXT_FOLDER = CORPUS_FOLDER + 'files_txt/'
TRAINING_T_FOLDER = CORPUS_FOLDER + 'files_t/'
