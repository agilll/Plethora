


# folders and filenames involved in corpus construction

TXT_FOLDER = "files_txt/"
SPW_FOLDER = "files_s_p_w/"
T_FOLDER = "files_t/"
