These are the templates for the interface of the main apps:

template.html - for the general tool

template-corpus.html - for the corpus tool
