from requests_futures.sessions import FuturesSession
from px_aux import URL_DB as _URL_DB


# to get wikicats and subjects from a text
# receives: the text
# returns: a dictionary result:
#    result['error']  with a message (string), or
#    result['wikicats'] with a list of wikicats (strings)
#    result['subjects'] with a list of subjects (strings)
def getCategoriesInText(texto):
	import requests
	from px_aux import URL_DB_SL_annotate as _URL_DB_SL_annotate

	result = {}

	# make a query to DB-SL with texto
	try:
		objParams = {"text": texto, "confidence": 0.5, "support": 1}
		# annotateTextRequest = requests.get(_URL_DB_SL_annotate, params=objParams, headers={"Accept": "application/json"})
		annotateTextRequest = requests.post(_URL_DB_SL_annotate, data=objParams, headers={"Accept": "application/json"})
	except Exception as e:
		print("ERROR getCategoriesInText(): Problem querying DB-SL", str(e))
		result["error"] = "Problem querying DB-SL --> "+str(e)
		return result;

	try:
		dbpediaText = annotateTextRequest.json()
	except Exception as e:
		print("ERROR getCategoriesInText(): Problem jsoning DB-SL response:", annotateTextRequest.content)
		result["error"] = "Problem with json DB-SL response: the query does not return the expected JSON --> "+str(e)
		return result;

	dbpediaManager = DBManager()

	try:
		dbpediaManager.scanEntities(dbpediaText)
	except Exception as e:
		print("ERROR getCategoriesInText(): Problem scanning DB-SL response: error in scanEntities --> "+str(e))
		result["error"] = "Problem with DB-SL: error in scanEntities --> "+str(e)
		return result;

	entities = dbpediaManager.getEntitiesAfterOffset(0)

	if len(entities) == 0:
		print("Warning getCategoriesInText(): No entities in text")

	print("\nInitially, there are entities:", len(entities))
	for entity in entities:
		print(entity["@URI"])

	# filter duplicated entities (same entity identified in different parts of the text)
	uniqueEntities = []
	for entity in entities:
		if entity["@URI"] in list(map(lambda x: x["@URI"], uniqueEntities)):
			continue
		uniqueEntities.append(entity)

	entities = uniqueEntities

	print("\nBut unique entities: ", len(entities))
	for entity in entities:
		print(entity["@URI"])

	# filter entities probably erroneously identified
	# a right entity is required to share wikicats with some other entity in the set
	print("\nFiltering by wikicats sharing")
	rightEntities = []
	for entity in entities:
		wki = entity["wikicats"]	# wikicats of this entity
		wkic = []	# wikicats of all the entities in the set except this one
		for ej in entities:
			if entity["@URI"] == ej["@URI"]:
				continue

			wkic.extend(ej["wikicats"])
		intersec = set(wkic).intersection(wki) # is there intersection?
		if len(intersec) > 0:
			rightEntities.append(entity)
		else:
			print("Discarded entity: ", entity["@URI"])

	entities = rightEntities

	print("\nAfter the filtering by wikicat sharing there are:", len(entities))
	for entity in entities:
		print(entity["@URI"])


	# a right entity is required to share subjects with some other entity in the set
	print("\nFiltering by subject sharing")
	rightEntities = []
	for entity in entities:
		sbi = entity["subjects"]	# subjects of this entity
		sbic = []	# subjects of all entities except this
		for ej in entities:
			if entity["@URI"] == ej["@URI"]:
				continue
			sbic.extend(ej["subjects"])
		intersec = set(sbic).intersection(sbi) # is there intersection?
		if len(intersec) > 0:
			rightEntities.append(entity)
		else:
			print("Discarded entity: ", entity["@URI"])

	entities = rightEntities

	print("\nAfter the filtering by subject sharing there are", len(entities))
	for entity in entities:
		print(entity["@URI"])




	# to return the list of the wikicats of the entities identified in the text
	wikicats = []
	for entity in entities:
		wikicats.extend(entity["wikicats"])

	setWikicats = list(set(wikicats))  # removes duplicates
	result["wikicats"] = setWikicats

	# from collections import Counter
	# counts = Counter(wikicats)
	# repetidas = [value for value, count in counts.items() if count > 1]
	#
	# print("\nwikicats repetidas = ", repetidas)
	# print("\nwikicats unicas = ", set(wikicats)-set(repetidas))

	# to return the list of the subjects of the entities identified in the text
	subjects = []
	for entity in entities:
		subjects.extend(entity["subjects"])

	subjects = list(set(subjects))  # removes duplicates
	result["subjects"] = [s.split(':')[-1] for s in subjects]   # original format = http://dbpedia.org/resource/Category:Ionian_Revolt, change to Ionian_Revolt

	# to return the list of URIs of the entities identified in the text
	uris = []
	for entity in entities:
		listTypes = entity["combinedTypes"]
		if ("Person" in listTypes):
			uris.append(entity["@URI"])
			continue
		if ("Location" in listTypes) or ("Place" in listTypes) or ("City" in listTypes) or ("Country" in listTypes):
			uris.append(entity["@URI"])
			continue
		if "Event" in listTypes:
			uris.append(entity["@URI"])
			continue

	uris = list(set(uris))  # removes duplicates
	result["URIs_persons_places_events"] = uris

	return result;






# this is not used?
# to get types from a text
# receives: the text
# returns: a dictionary result:
#    result['error']  with a message (string), or
#    result['resources'] with the types for each entity (string, string list)
def getTypesInText(texto):
	import requests
	from px_aux import URL_DB_SL_annotate as _URL_DB_SL_annotate

	result = {}

	try:
		annotateTextRequest = requests.get(_URL_DB_SL_annotate, params={"text": texto, "confidence": 0.5, "support": 1}, headers={"Accept": "application/json"})
	except Exception as e:
		print("ERROR getTypesInText(): Problem querying DB-SL")
		result["error"] = "Problem with DB-SL --> "+str(e)
		return result;

	dbpediaManager = DBManager()
	try:
		dbpediaText = annotateTextRequest.json()
	except Exception as e:
		print("ERROR getTypesInText(): "+str(e)+": "+annotateTextRequest.content)
		result["error"] = "Problem with DB-SL: the query does not return the expected JSON --> "+str(e)
		return result;

	dbpediaManager.scanEntities(dbpediaText)
	entities = dbpediaManager.getEntitiesAfterOffset(0)

	if entities == []:
		print("ERROR getTypesInText(): DBpedia does not answer to the query of types")
		result["error"] = "DBpedia does not answer to the query of types"
		return result;
	else:
		resources = []
		for entity in entities:
			tipos = entity["rawSparqlTypes"]
			ltipos = tipos.split(";")
			resources.append((entity['entityName'], ltipos))

	result["resources"] = resources

	return result;








# This is a class to store information about the entities detected in a text by the DBpedia SpotLight
# this info is enhanced by two new queries to DBpedia: to get types and to get person props
# such information is classified in three dictionaries, according to three different indices
# used in routesCorpus.py

# These two special cases are treated this way:
# two different surfaceForms leading to the same URL  --> two entities in the list stored in such byUri URL key
# one surfaceForm leading to several distinct URLs:  no special case

class DBManager:

	# to initialize data structures for this instance
	def __init__(self):
		# entityData is the variable to store the information about the entities  (a dictionary with 3 dictionaries, the same info organized in 3 different ways)
		# 'byUri': {}     key=URI, value=entity list  (all the entities with the same URI and different surfaceForms)
		# 'byType': {}    key=type (string), value=entity list (all the entities with such type)
		# 'byOffset': {}  key=offset, value=entity

		self.entityData = {'byUri': {}, 'byType': {}, 'byOffset': {}}
		self.session = FuturesSession() # to manage asynchronous requests


	# function to request an entity list, the one for the URI received as parameter
	# returns the entity list indexed in 'byUri'
	def getByUriEntityList(self, uri):
		try:
			return self.entityData["byUri"][uri]
		except:
			return None


	# to request all the managed entities
	# returns the dictionary 'byUri', with all the entities
	def getByUri(self):
		return self.entityData["byUri"]


	# to request all the entities whose offset is greater than the one received as parameter
	# returns an entity list, with those entities verifying the requirement
	def getEntitiesAfterOffset(self, offset = 0):
		return list(filter(lambda x: int(x["@offset"]) >= offset, self.entityData['byOffset'].values()))


	# to request all data, the structure with the 3 dictionaries
	def getDictionaries(self):
		return self.entityData

	# to store new data, the structure with the 3 dictionaries
	def setDictionaries(self, ed):
		self.entityData = ed
		return


	# to request all the entityNames a given surfaceForm leads to
	# also includes those entityNames a superString of surfaceForm leads to  (e.g. if surfaceForm='Persians', the sf 'The Persians' matches and 'the_persians' is included)
	def getEntityNamesOfSF(self, surfaceForm):
		surfaceForm2 = surfaceForm.lower()
		byUri = self.entityData["byUri"]
		sfs = {}

		for url in byUri:
			entityList = byUri[url]
			for entity in entityList:
				sf = entity["@surfaceForm"].lower()

				if sf not in sfs:
					sfs[sf] = [surfaceForm2]

				sfs[sf].append(entity["entityLowerName"])

		listaNameEntities = [surfaceForm2]

		for k in sfs:
			if surfaceForm2 in k:
				listaNameEntities.extend(sfs[k])

		return list(set(listaNameEntities))



	# to organize all info in the dictionaries
	# receives the information returned by the DB-SL containing the set of entities identified in a text
	def scanEntities(self, dbsl_output):
		try:
			dbsl_entities = dbsl_output["Resources"]
		except:
			print("Warning scanEntities(): no Resources")
			return

		# obtains all URIs corresponding to the entities identified by the DB-SL
		totalUris = [x["@URI"] for x in dbsl_entities]
		noDups = list(set(totalUris))  # remove duplicates
		totalUris = ["<"+ x + ">" for x in noDups]
		totalUris = " ".join(totalUris) # builds string  "<uri1> <uri2> ...  <urin>"

		# query to obtain for each URI: label, dct:subject, rdf:type
		query = """
		SELECT ?uri ?label (group_concat(distinct ?subject; separator=';') as ?subjects) (group_concat(distinct ?type; separator=';') as ?types)   WHERE {
			VALUES ?uri {"""+ totalUris +"""} .
			?uri rdfs:label ?label; rdf:type ?type .
			?uri dct:subject ?subject .
			FILTER(regex(?type,'http://dbpedia.org/ontology|http://dbpedia.org/class/yago')) .
			FILTER(lang(?label) = 'en')}
			GROUP BY ?label ?uri
		"""
		# session is a FutureSessions object created in initialization
		requestTypes = self.session.post(_URL_DB, data={"query": query}, headers={"accept": "application/json"})


		# query to obtain for each URI only those ones corresponding to persons (they have some typical properties as birthDate, deathDate...
		query = """
		SELECT ?uri ?label (group_concat(distinct ?p; separator=';') as ?properties)  WHERE {
			VALUES ?uri {""" + totalUris + """} .
			VALUES ?p {dbo:birthDate dbo:birthPlace dbo:deathPlace dbo:deathDate dbp:birthDate dbp:birthPlace dbp:deathPlace dbp:deathDate dbo:parent dbo:commander foaf:gender} .
			?uri rdfs:label ?label; rdf:type ?t; ?p ?v .
			FILTER(lang(?label) = 'en') .
			FILTER(regex(?t,'http://dbpedia.org/ontology/Person|http://dbpedia.org/class/yago/Person'))}
			GROUP BY ?uri ?label
		"""
		requestPersonProps = self.session.post(_URL_DB, data={"query": query}, headers={"accept": "application/json"})

		# wait for query1 to complete
		response1 = requestTypes.result()
		if response1.status_code != 200:
			print("ERROR scanEntities(): problem querying types to DBpedia. Answer HTTP code: ", response1.status_code)
			return

		resultTypes = requestTypes.result().json()  # obtain the JSON result of the first one

		# wait for query2 to complete
		response2 = requestPersonProps.result()
		if response2.status_code != 200:
			print("ERROR scanEntities(): problem querying person props to DBpedia. Answer HTTP code: ", response2.status_code)
			return

		resultPersonProps = requestPersonProps.result().json()   # obtain the JSON result of the first one


		# add new fields for all entities to create enhanced entities
		dbsl_enhancedEntities = []
		for entity in dbsl_entities:
			entity["times"] = 1    # number of times that this entity appears associated to this surfaceForm ( will be increased when new ones are added)
			entity["combinedTypes"] = []
			entity["personProperties"] = []
			entity["sparqlTypes"] = []
			entity["wikicats"] = []
			entity["subjects"] = []
			entity["rawSparqlTypes"] = []

			uri = entity["@URI"]
			nameEntity = uri.split("/")[-1]
			entity["entityName"] = nameEntity   # these two fields are needed for the preprocessing before training
			entity["entityLowerName"] = nameEntity.lower()

			dbsl_enhancedEntities.append(entity)


		# to avoid duplicates in the tupla URI/surfaceForm (it is a list of strings with such format)
		checkDuplicates = []

		# now study and clasify all recieved entities
		# 1. put all entities in byOffset, also put in byUri if no repeated
		# 2. Add to byUri sparql types
		# 3. Add to byUri personProps
		# 4. Create byType with the byUri data
		# 5. Update byOffset with the new info included in byUri (sparqlTypes, Wikicats, personProps, combinedTypes...)


		# 1. put all enhanced entities in byOffset, also put in byUri if not repeated the pair URL/sf
		for entity in dbsl_enhancedEntities:
			# entity is a dictionary with all the fields returned by DB-SL (sec 6.4)
			# put entity in dictionary 'byOffset', with key=offset, and value the entity, even if different sf lead to the same URI
			# as DB_SL returns them in increasing order, the dictionary is ordered in such sense

			# this should not happen, but it happens once in our training texts, a DB-SL bug?
			if entity["@offset"] in self.entityData['byOffset']:
				print(entity["@offset"], "already asigned, not added\n", entity, "\n\n", self.entityData['byOffset'][entity["@offset"]] )
			else:
				self.entityData['byOffset'][entity["@offset"]] = entity

			# the string URI/surfaceForm must be not duplicated to put this entity in 'byUri'
			# if duplicated, this entity is skipped for the rest of this loop, so it has only been included in byOffset with the original information
			if entity["@URI"]+"/"+entity["@surfaceForm"] not in checkDuplicates:
				# if not duplicated, the unique string is added to the checkDuplicates list
				checkDuplicates.append(entity["@URI"]+"/"+entity["@surfaceForm"])

				# put the entity in byUri if not already included
				if entity['@URI'] not in self.entityData['byUri']:
					self.entityData['byUri'][entity['@URI']] = []  # if the URI no exists, create the list

				self.entityData['byUri'][entity['@URI']].append(entity)  # add the new one

			else:
				# increase 'times' for every occurrence of this URI/SF
				entityList = self.entityData['byUri'][entity['@URI']]
				for ent in entityList:
					if ent["@surfaceForm"] == entity["@surfaceForm"]:
						ent["times"] += 1
						break


		# now add the new types queried with SPARQL for all entities and add to 'byUri'
		# 2. Add SPARQL types to byUri
		for rt in resultTypes["results"]["bindings"]:
			# rt is a dictionary with keys=[uri, label, subjects, types], their values are dictionaries with the payload in the field 'value' (sec 6.3)

			# process the new types and wikicats obtained with the SPARQL query
			_sparqlTypes = []
			_wikicats = []
			_rawSparqlTypes = rt["types"]["value"]

			# to isolate the new types and wikicats obtained with SPARQL
			for _type in _rawSparqlTypes.split(";"):
				# if the type starts with "http://dbpedia.org/ontology/", is added to the list of new types (sparqlTypes), without the prefix
				if _type.startswith("http://dbpedia.org/ontology/"):
					_t = _type.replace("http://dbpedia.org/ontology/", "")
					_sparqlTypes.append(_t)
				# if the type starts with "http://dbpedia.org/class/yago/Wikicat", is added to the list of wikicats (wikicats), without the prefix
				elif _type.startswith("http://dbpedia.org/class/yago/Wikicat"):
					_t = _type.replace("http://dbpedia.org/class/yago/Wikicat", "")
					_wikicats.append(_t)

			uri = rt["uri"]["value"] # get the URI
			entityList = self.entityData["byUri"][uri]  # obtain the entity list from byUri corresponding to such URI

			# add such info to all the entities corresponding to such list
			newEntityList = []
			for entity in entityList:
				entity["sparqlTypes"] = _sparqlTypes
				entity["wikicats"] = _wikicats
				entity["subjects"] = rt["subjects"]["value"].split(";")  # copy the list of subjects, as a list
				entity["rawSparqlTypes"] = _rawSparqlTypes  # copy the raw data of the SPARQL query, a a string

				# create new 'combinedTypes' field
				dbslTypes = entity["@types"].split(",")  # get the original types returned by DB-SL
				dbslTypes = list(filter(lambda x: x.startswith("DBpedia:"), dbslTypes))  # remove those not starting by 'DBpedia:'
				cleanDbslTypes = list(map(lambda x: x.replace("DBpedia:", ""), dbslTypes))  # remove the 'DBpedia:' prefix

				# add new field 'combinedTypes' with original+new types
				combinedTypes = list(set(cleanDbslTypes) | set(entity["sparqlTypes"]))
				entity["combinedTypes"] = combinedTypes

				newEntityList.append(entity)

			# put the new list in byUri, replacing the old
			self.entityData["byUri"][uri] = newEntityList


		# now the same processing with the URIs representing persons (have typical peroson props)
		# 3. Add person props to byUri
		for rt in resultPersonProps["results"]["bindings"]:
			# rt is a dictionary with keys=[uri, label, properties], their values are dictionaries with the payload in the field 'value' (sec 6.3)
			uri = rt["uri"]["value"]  # get the URI

			entityList = self.entityData["byUri"][uri]   # obtain the entity list from byUri corresponding to such URI

			# add such info to all the entities corresponding to such list
			newEntityList = []
			for entity in entityList:
				entity["personProperties"] = rt["properties"]["value"].split(";")  # add a new field with person props, a list
				newEntityList.append(entity)

			# put the new list in byUri, replacing the old
			self.entityData["byUri"][uri] = newEntityList



		# now study entities indexed in byUri to create byType (a dictionary with all types, each one with the list of entities from such type)
		# 4. Create byType with byUri data
		for entityList in self.entityData['byUri'].values():
			for entity in entityList:
				# entity runs through all the entities indexed in byUri
				combinedTypes = entity["combinedTypes"]

				# study all types in this entity
				for t in combinedTypes:
					if t not in self.entityData['byType']:  # if this type does mot exist in byType dictionary, the new key is created
						self.entityData['byType'][t] = []

					self.entityData['byType'][t].append(entity)   # add this entity to the list of entities of such type



		# update the information in byOffset with such fields added after step 1
		# 5. update byOffset with new data included in byURI (sparqlTypes, Wikicats, personProps, combinedTypes...)
		for i in self.entityData['byOffset']:
			# obtain the entity corresponding to such offset i
			entity = self.entityData['byOffset'][i]

			# get the first entity corresponding to such URI (all of them have been populated with the same info)
			newEntityList = self.entityData["byUri"][entity["@URI"]]
			newEntity = newEntityList[0]

			# complete byOffset entity with  new fields added to the byUri entity
			entity["sparqlTypes"] = newEntity["sparqlTypes"]
			entity["wikicats"] = newEntity["wikicats"]
			entity["combinedTypes"] = newEntity["combinedTypes"]
			entity["subjects"] = newEntity["subjects"]
			entity["rawSparqlTypes"] = newEntity["rawSparqlTypes"]
			entity["personProperties"] = newEntity["personProperties"]

			 # and put back the byOffset entity in byOffset, replacing the old one
			self.entityData['byOffset'][entity["@offset"]] = entity


	# to rebuild byUri and byType if byOffset has changed
	def rebuild(self):
		newByType = {}
		newByUri = {}
		checkDuplicates = []

		for entity in self.getEntitiesAfterOffset(0):
			# the string URI/surfaceForm must be not duplicated to put this entity in 'byUri'
			# if duplicated, this entity is skipped for the rest of this loop, so it has only been included in byOffset with the original information
			if entity["@URI"]+"/"+entity["@surfaceForm"] not in checkDuplicates:
				# if not duplicated, the unique string is added to the checkDuplicates list
				checkDuplicates.append(entity["@URI"]+"/"+entity["@surfaceForm"])

				# put the entity in byUri if not already included
				if entity['@URI'] not in newByUri:
					newByUri[entity['@URI']] = []  # if the URI no exists, create the list

				newByUri[entity['@URI']].append(entity)  # if already exists, add the new one corresponding to another sf


			# entity runs through all the entities indexed in byOffset
			combinedTypes = entity["combinedTypes"]

			# study all types in this entity
			for t in combinedTypes:
				if t not in newByType:  # if this type does mot exist in byType dictionary, the new key is created
					newByType[t] = []

				newByType[t].append(entity)   # add this entity to the list of entities of such type

		self.entityData["byType"] = newByType
		self.entityData["byUri"] = newByUri

# end DBManager
